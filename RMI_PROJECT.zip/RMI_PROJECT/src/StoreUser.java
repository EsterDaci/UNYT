/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.*;
import java.net.MalformedURLException;
import java.util.Locale;
import java.text.NumberFormat;
import javax.swing.*;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.GridLayout;

/**
 *
 * @author User
 */
public class StoreUser extends JFrame {

    private ElectronicStore es;
    private JTextArea printArea;
    private JTextField productField;
    private JTextField productFieldNumber;
    private JTextField saleField;
    private JTextField listProductField;
    private JTextField totalSaleField;
    private JTextField listProductLessTen;
    private JButton queryButton;

    public StoreUser() {

        super();

        final int DEFAULT_FRAME_WIDTH = 430;
        final int DEFAULT_FRAME_HEIGHT = 500;
        setSize(DEFAULT_FRAME_WIDTH, DEFAULT_FRAME_HEIGHT);
        addWindowListener(new WindowCloser());
        setTitle("UNYT : Store User Window");
        printArea = new JTextArea(10, 10);

        productField = new JTextField(10);
        productFieldNumber = new JTextField(10);

        queryButton = new JButton("Query Database");
        queryButton.addActionListener(new ButtonListener());

        queryButton = new JButton("Query Database");
        
        // add components to content pane
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(3, 1));
        contentPane.add(printArea);

        // arrange the label and text field in a panel
        JPanel query1Panel = new JPanel();
        query1Panel.add(new JLabel("ProductName: "));
        query1Panel.add(productField);

        // place the button in a panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(queryButton);

        JPanel buttonPane2 = new JPanel();
        buttonPanel.add(queryButton);
        // stack up these two panels in another panel

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(3, 1));
        centerPanel.add(query1Panel);
        centerPanel.add(buttonPanel);
        centerPanel.add(buttonPane2);

        JPanel ProductNumberPanel = new JPanel();
        JButton buttonNumber = new JButton("Find Product Number that are in stock: ");
        queryButton.addActionListener(new ButtonTotalNumberListener());
        JPanel query5Panel = new JPanel();
        query5Panel.add(buttonNumber);

        ProductNumberPanel.add(query5Panel);
        contentPane.add(ProductNumberPanel);
        contentPane.add(centerPanel);
        
        //List of products
        
      listProductField = new JTextField(10);
//      listProduct = new JTextField(10);

      JPanel query3Panel = new JPanel();
      query3Panel.add(new JLabel("List of products: "));
      query3Panel.add(listProductField);

      JPanel listOfProduct = new JPanel();
      listOfProduct.setLayout(new GridLayout(3, 1));
      listOfProduct.add(query3Panel);
      
      contentPane.add(listOfProduct);
      
      //Product With Unit Less 10
         
      listProductLessTen = new JTextField(10);
      

      JPanel query7Panel = new JPanel();
      query7Panel.add(new JLabel("List of products With Unit Less Than 10: "));
      queryButton.addActionListener(new ButtonProductWithUnitLess10Listener());
      query3Panel.add(listProductLessTen);

      JPanel listProductLessTenPanel = new JPanel();
      listProductLessTenPanel.setLayout(new GridLayout(3, 1));
      listProductLessTenPanel.add(query3Panel);
      
      listProductLessTenPanel.add(query7Panel);
      contentPane.add(listProductLessTenPanel);
        
      
      //Total Sale 
      totalSaleField = new JTextField(10);

      

      JPanel query6Panel = new JPanel();
      query6Panel.add(new JLabel("Account ID to withdraw: "));
      query6Panel.add(totalSaleField);

      JPanel withdrawPanel = new JPanel();
      withdrawPanel.setLayout(new GridLayout(3, 1));
      withdrawPanel.add(query6Panel);
      withdrawPanel.add(query7Panel);

      JButton buttonTotalSale = new JButton("Total Sale : ");
      buttonTotalSale.addActionListener(new ButtonTotalSaleListener());
      JPanel query8Panel = new JPanel();
      query8Panel.add(buttonTotalSale);

      buttonTotalSale.add(query8Panel);
      contentPane.add(buttonTotalSale);
      
      
      
      
      setVisible(true);

    try {
      es = (ElectronicStore)Naming.lookup("rmi://localhost/ElectronicStore");
    } catch (MalformedURLException malformedException) {
      System.err.println("Bad URL: " + malformedException);
    } catch (NotBoundException notBoundException) {
      System.err.println("Not Bound: " + notBoundException);
    } catch (RemoteException remoteException) {
      System.err.println("Remote Exception: " + remoteException);
    }

    // Lookup account 4461
//    Products products = es.getProducts("1");
  }


     private class WindowCloser extends WindowAdapter
   {  public void windowClosing(WindowEvent event)
      {  System.exit(0);
      }
   }


    private class ButtonListener implements ActionListener
   {  public void actionPerformed(ActionEvent event)
      {  // get user input from text area
      try{
         if(!productField.getText().equals("")){
        System.out.println("opps" + productField.getText() + "000");
        Products pr = es.getProducts(productField.getText());
        productField.setText("");
        System.out.println("Currently in the database "
                + "there \n is this product with the "
                + "requested ID:" + pr.getProductName());
        printArea.setText("Currently in the database "
                + "there \n is this product with "
                + "the requested ID:" + pr.getProductName());
 }
     
             }catch (RemoteException remoteException) {
      System.err.println(remoteException);
    }
      }
     }
    
    

    private class ButtonTotalNumberListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + productField.getText() + "000");
                    Products pr = (Products) es.getProducts(productField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + pr.getProductNumberFromDatabase() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + pr.getProductNumberFromDatabase() + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }

    }

    private class ButtonListOfProductsListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + productField.getText() + "000");
                    Products pr = (Products) es.getProducts(productField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + pr.getProductsInfoFromDatabase() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + pr.getProductsInfoFromDatabase() + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }
    }

    private class ButtonProductWithUnitLess10Listener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + productField.getText() + "000");
                    Products pr = (Products) es.getProducts(productField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + pr.getProductWithUnitLess10() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + pr.getProductWithUnitLess10() + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }
    }

    private class ButtonTotalSaleListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + saleField.getText() + "000");
                    Sale sale = es.getSale(saleField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + sale.getTotalSale() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + sale.getTotalSale() + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }
    }

    private class ButtonTotalAmountOfSaleLastMonthListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + saleField.getText() + "000");
                    Sale sale = es.getSale(saleField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + sale.getTotalAmountOfSaleLastMonth() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + sale.getTotalAmountOfSaleLastMonth() + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }
    }

    private class ButtonNrOfSaleLastMonthListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + saleField.getText() + "000");
                    Sale sale = es.getSale(saleField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + sale.getNrOfSaleLastMonth() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + sale.getNrOfSaleLastMonth() + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }
    }    private class ButtonTotalAmountOfSaleListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {  // get user input from text area
            try {
                if (!productField.getText().equals("")) {
                    System.out.println("opps" + saleField.getText() + "000");
                    Sale sale = es.getSale(saleField.getText());
                    productField.setText("");
                    System.out.println("Currently in the database "
                            + "there \n there are" + sale.getTotalAmountOfSale() + " with the "
                            + "requested ID:");
                    printArea.setText("Currently in the database "
                            + "there \n there are" + sale.getTotalAmountOfSale()  + " with the "
                            + "requested ID:");
                }
            } catch (RemoteException remoteException) {
                System.err.println(remoteException);
            }
        }
    }

        
     
  public static void main(String[] args) {
    new StoreUser();
  }
    }

   
   
   
   
    

