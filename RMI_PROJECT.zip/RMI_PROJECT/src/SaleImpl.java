/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;

import java.rmi.RemoteException;
/**
 *
 * @author User
 */
public class SaleImpl implements Sale, Serializable{
    
    
    private ElectronicStore electronicStore;
//    private Product product;
    private Products  products;
    private int SaleId;
    private int totalSale;
    private int NrTotalSaleLastMonth;
    private int totalAmountOfSale;
    private int totalAmountOfSaleLastMonth;

    public SaleImpl(ElectronicStore electronicStore, int SaleId) {
        this.electronicStore = electronicStore;
        this.SaleId = SaleId;
    }

    
    
    
    
    
    
 
    public ElectronicStore getElectronicStore() throws RemoteException {
        return electronicStore;
    }

 

 
    public Products getProducts() throws RemoteException {
        return products;
    }

 
    public int getSalesId() throws RemoteException {
       return SaleId;
    }

    public int getTotalSale() throws RemoteException {
        return totalSale;
    }

    public int getNrOfSaleLastMonth() throws RemoteException {
        return NrTotalSaleLastMonth;
    }


    public int getTotalAmountOfSale() throws RemoteException {
        return totalAmountOfSale;
    }

  
    public int getTotalAmountOfSaleLastMonth() throws RemoteException {
        return totalAmountOfSaleLastMonth;
    }
    
}
