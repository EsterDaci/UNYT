/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.BorderLayout;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.net.MalformedURLException;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

/**
 *
 * @author User
 */
public class ElectronicStoreServer extends JFrame {

    private JPanel contentPane;
    private JButton buttonConnect;
    private JButton buttonDisconnect;
    private JLabel labelState;
    private boolean connected;
    private ElectronicStoreImpl ES;
    private JButton buttonExit = null;

    //NO ARGUMENT CONSTRUCTOR
    public ElectronicStoreServer() {
        super();
        this.setSize(302, 149);
        this.setMinimumSize(new Dimension(265, 125));
        this.setPreferredSize(new Dimension(265, 125));
        this.setResizable(false);
        contentPane = new JPanel();
        this.setContentPane(contentPane);
        this.setTitle("Store Server");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        labelState = new JLabel();
        labelState.setText("Pending to Start RMI Server...");
        buttonConnect = new JButton();
        buttonConnect.setText("Connect");
        buttonConnect.setPreferredSize(new Dimension(110, 25));
        buttonConnect.setMaximumSize(new Dimension(100, 25));
        buttonConnect.setMinimumSize(new Dimension(100, 25));
        buttonConnect.setSize(new Dimension(80, 25));
        buttonConnect.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                buttonConnect_mouseClicked(e);

            }
        });
        buttonConnect.setEnabled(true);
        buttonDisconnect = new JButton();
        buttonDisconnect.setText("Disconnect");
        buttonDisconnect.setPreferredSize(new Dimension(110, 25));
        buttonDisconnect.setMaximumSize(new Dimension(100, 25));
        buttonDisconnect.setMinimumSize(new Dimension(100, 25));
        buttonDisconnect.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                buttonDisconnect_mouseClicked(e);
            }
        });
        buttonDisconnect.setEnabled(false);
        contentPane.setLayout(new BorderLayout());
        contentPane.setSize(new Dimension(260, 100));
        contentPane.setPreferredSize(new Dimension(260, 100));
        contentPane.setMinimumSize(new Dimension(260, 100));
        contentPane.setMaximumSize(new Dimension(260, 100));

        JPanel panelbutton1 = new JPanel();
        panelbutton1.add(buttonConnect);

        JPanel panelbutton2 = new JPanel();
        panelbutton1.add(buttonDisconnect);

        contentPane.add(labelState, "North");
        contentPane.add(panelbutton1, "Center");
        //contentPane.add(panelbutton2,"Center");

        this.setVisible(true);

    }

    public void buttonDisconnect_mouseClicked(MouseEvent e) {
        if (connected) {
            disconnectServer();
        }
    }

    public void buttonConnect_mouseClicked(MouseEvent e) {
        if (!connected) {
            connectServer();
        }
    }

    private void connectServer() {
        try {
            ES = new ElectronicStoreImpl();

            Naming.rebind("rmi://localhost/ElectronicStore", ES);
            connected = true;
        } catch (MalformedURLException err) {
            System.out.println(err.getMessage());
            err.printStackTrace();
        } catch (RemoteException err) {
            System.out.println(err.getMessage());
            err.printStackTrace();
        }
        if (connected) {
            buttonDisconnect.setEnabled(true);
            buttonConnect.setEnabled(false);
            labelState.setText("RMI Server started");
            System.out.println("Server Connected.");
        } else {
            buttonDisconnect.setEnabled(false);
            buttonConnect.setEnabled(true);
            labelState.setText("Pending to start RMi Server...");
            System.out.println("Server Disconnected.");
        }
    }

    private void disconnectServer() {
        ES = null;
        try {
            Naming.unbind("ElectronicStore");
            connected = false;
        } catch (RemoteException err) {
            System.out.println(err.getMessage());
            err.printStackTrace();
        } catch (NotBoundException err) {
            connected = false;
            System.out.println(err.getMessage());
            err.printStackTrace();
        } catch (MalformedURLException err) {
            System.out.println(err.getMessage());
            err.printStackTrace();
        }
        if (connected) {
            buttonDisconnect.setEnabled(true);
            buttonConnect.setEnabled(false);
            labelState.setText("RMI Server started");
            System.out.println("Server Connected.");
        } else {
            buttonDisconnect.setEnabled(false);
            buttonConnect.setEnabled(true);
            labelState.setText("Pending to start RMi Server...");
            System.out.println("Server Disconnected.");
        }
    }

    public static void main(String args[]) {
        new ElectronicStoreServer();

    }
}
