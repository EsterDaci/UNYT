/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author User
 */
public interface Products extends Remote {
    // Add method to return master ElectronicStore
      public ElectronicStore getElectronicStore()
       throws RemoteException;


    // Add method to return Product
//   public Product getProduct()
//         throws RemoteException;
    
    public Sale getSale()
            throws RemoteException;

    // Add method to return balance of this account
    public int getProductNumberFromDatabase()
            throws RemoteException;

  // Add method to return the name of this client
  public String getProductName()
       throws RemoteException;
  
  public int getProductID()
       throws RemoteException;
   
  
    
  public int getProductsInfoFromDatabase()
       throws RemoteException;
  
    
  public int getProductWithUnitLess10()
       throws RemoteException;
  
  
  
}
