/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.rmi.RemoteException;

/**
 *
 * @author User
 */
public class ProductsImpl implements Products, Serializable {

    private ElectronicStore electronicStore;
//    private Product product;
    private Sale sale;
    private int nrProd;
    private String ProductName;
    private int prodID;
    private int ListOfProduct;
    private int ListOfProductAvQuantLessTen;
    private int price;
    private int dateofArrival;

    public ProductsImpl(ElectronicStore electronicStore, String ProductName, int prodID, int price, int dateofArrival) {
        this.electronicStore = electronicStore;
        this.ProductName = ProductName;
        this.prodID = prodID;
        this.price = price;
        this.dateofArrival = dateofArrival;
    }

    
    
    
    public ElectronicStore getElectronicStore() throws RemoteException {
        return electronicStore;
    }

//    @Override
//    public Product getProduct() throws RemoteException {
//        return product;
//        
//    } 

    
    public Sale getSale() throws RemoteException {
        return sale;
    }

    public int getNrOfProducts() throws RemoteException {
        return nrProd;
    }

    
    public String getProductName() throws RemoteException {
        return ProductName;
    }

    
    public int getProductID() throws RemoteException {
        return prodID;
    }

    public int getListOfProduct() throws RemoteException {
       return ListOfProduct;
    }

    public int getListOfProductAvQuantLessTen() throws RemoteException {
        return ListOfProductAvQuantLessTen;
    }

    
    public int getProductNumberFromDatabase() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    public int getProductsInfoFromDatabase() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public int getProductWithUnitLess10() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
 
    
}
