/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author User
 */
public interface ElectronicStore extends Remote {

    // Add method to return an Products service
    public Products getProducts()
            throws RemoteException;

    public Sale getSale()
            throws RemoteException;

   public int getProductId(int productId)
            throws RemoteException;

   public Products getProducts(String text)
   throws RemoteException;
  public Sale getSale(String text)
       throws RemoteException;
    
}
