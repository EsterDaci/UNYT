/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author User
 */
public interface Sale extends Remote {
        // Add method to return master ElectronicStore
      public ElectronicStore getElectronicStore()
       throws RemoteException;


    // Add method to return Product
//   public Product getProduct()
//         throws RemoteException;
    
 

    public Products getProducts()
            throws RemoteException;

    public int getSalesId()
            throws RemoteException;

    public int getTotalSale()
            throws RemoteException;

  
    public int getNrOfSaleLastMonth()
            throws RemoteException;

    public int getTotalAmountOfSale()
            throws RemoteException;

    public int getTotalAmountOfSaleLastMonth()
            throws RemoteException;
}
