/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.util.Hashtable;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.sql.*;
//import static sun.io.Win32ErrorMode.initialize;

/**
 *
 * @author User
 */
public final class ElectronicStoreImpl extends UnicastRemoteObject implements ElectronicStore {

    private Hashtable products;
    private Hashtable productInfo;
    private Hashtable sale;
    private Connection conn;
    private Statement s;
    private int productId;
    // public No-argument constructor

    public ElectronicStoreImpl()
            throws java.rmi.RemoteException {
        super();
        initialize();
    }

    public Products getProducts(int ProductId) throws RemoteException {
        ProductsImpl product = (ProductsImpl) products.get(ProductId);
        return product;
    }

    public int getProductId(int productId) throws RemoteException {
        return productId;
    }
    //com.mysql.jdbc.Driver  com.mysql.cj.jdbc.Driver

    public boolean initializeConnection(String SERVER, String DATABASE, String USER_ID,
            String PASSWORD) throws ClassNotFoundException, SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
//          String path = ("jdbc:mysql://localhost" + SERVER + "/electronicsproducts" + DATABASE + "?root="
//                   + USER_ID + "&Ester123=" + PASSWORD);
          conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/electronicsproducts","root","Ester123");
       //  conn = DriverManager.getConnection(path);
            s = conn.createStatement();
            return true;
        } catch (SQLException e) {
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public void CreateConnection() {
        if (conn == null) {
            try {
                initializeConnection("localhost", "electronicsproducts", "root", "Ester123");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void initialize()
            throws java.rmi.RemoteException {
        // Create the hashtables
        products = new Hashtable(50);
        productInfo = new Hashtable(50);
        sale = new Hashtable(50);
        CreateConnection();
    
        getProductNumberFromDatabase();
        getListOfProductsInfoFromDatabase();
        getListOfProductWithAvUnitLess10();
        getTotalSale();
        getNrOfSaleLastMonth();
        getTotAmOfSale();
        getTotAmOfSaleLastMonth();

    }

    public void getListOfProductsInfoFromDatabase() {
       // ArrayList<Integer> ids = new ArrayList<Integer>();
         System.out.println("------------------------------------");
         System.out.println("Reading Products Information  from the database:");
        try {
            Statement t = conn.createStatement();
            String sql = "Select * from electronicsproducts.products";
            ResultSet r = t.executeQuery(sql);
  
        if(r.next()){ 
				do{
				System.out.println(r.getString("ProductID")+","+r.getString("ProductName")+","+r.getString("Price")+","+r.getString("DateOfArrival")+","+r.getString("Manufacturer")+","+r.getString("AvailableQuantity"));
				}while(r.next());
			}
			else{
				System.out.println("Record Not Found...");
			}
			
		}
		catch(Exception e){
			System.out.println(e);
		}
	}        

  public int getProductNumberFromDatabase() throws RemoteException{

    int numOfProd = 0;
      System.out.println("------------------------------------");
      System.out.println("Reading Number of products  from the database:");
        try {
          Statement st = conn.createStatement();
           String sql = "SELECT count(*) as NumberOfProduct FROM electronicsproducts.products";
            ResultSet r = st.executeQuery(sql);
       while(r.next())  {   
            
   numOfProd =r.getInt("NumberOfProduct");
       }
System.out.println(numOfProd);
        } catch(Exception e){
        e.printStackTrace();
       }
        return numOfProd;
      

 }

   public void getListOfProductWithAvUnitLess10() {
 
   System.out.println("------------------------------------");
   System.out.println("Reading Product Information with Unit less than 10 from the database:");
       try {
           Statement t;
            t = conn.createStatement();
            String sql = "Select * from electronicsproducts.products where AvailableQuantity<10";
           ResultSet r = t.executeQuery(sql);
 
        if(r.next()){ 
				do{
				System.out.println(r.getString("ProductID")+","+r.getString("ProductName")+","+r.getString("Price")+","+r.getString("DateOfArrival")+","+r.getString("Manufacturer")+","+r.getString("AvailableQuantity"));
				}while(r.next());
			}
			else{
				System.out.println("Record Not Found...");
			}
			
		}
		catch(SQLException e){
			System.out.println(e);
		}
	}    
   

    public void  getTotalSale() {
   System.out.println("------------------------------------");
   System.out.println("Reading total sale from the database:");
        int numOfSale=0;
        //    ArrayList<Integer> ids = new ArrayList<Integer>();
        try {
            Statement t = conn.createStatement();
            String sql = "select count(SalesID) as TotalSale from electronicsproducts.sales";
            ResultSet r = s.executeQuery(sql);
          while(r.next())  {
               numOfSale=r.getInt("TotalSale");
          }

System.out.println(numOfSale);
        } catch (SQLException e) {
            System.out.println(e);
        }
        
    }

    public void getNrOfSaleLastMonth() {
        int NrOfSaleLastMonth=0;
        // ArrayList<Integer> ids = new ArrayList<Integer>();
        try {
            Statement t = conn.createStatement();
            String sql = "SELECT count(*) as NrOfSaleLastMonth FROM electronicsproducts.sales \n"
                    + " where DateOfSale between  20190701 and 20190730";

            ResultSet r = t.executeQuery(sql);
          while(r.next())  {
 NrOfSaleLastMonth=r.getInt("NrOfSaleLastMonth");
          }
System.out.println(NrOfSaleLastMonth);
        } catch (SQLException e) {
             System.out.println(e);
        }
       
    }

    public void getTotAmOfSale() {
       int   sumOfSale =0;
          System.out.println("------------------------------------");
      System.out.println("Reading total amount of sale from the database:");
       
        try {
            Statement t = conn.createStatement();
            String sql = "select sum(TotalAmount) as  total from electronicsproducts.sales";

            ResultSet r = t.executeQuery(sql);
          while(r.next())  {
         sumOfSale=r.getInt("total");
          }
  System.out.println(sumOfSale);
        } catch (SQLException exc) {
            System.out.println(exc);
        }
      
    }

    public void getTotAmOfSaleLastMonth() {
        int    sumOfSalesLastMonth=0;
          System.out.println("------------------------------------");
      System.out.println("Reading total amount of sale from last month  from the database:");
      
        try {
            Statement s = conn.createStatement();
            String sql = "   select sum(TotalAmount) as TotalAmount  from electronicsproducts.sales \n"
                    + "where DateOfSale between  20190701 and 20190730";

            ResultSet r = s.executeQuery(sql);
             while(r.next())  {
          sumOfSalesLastMonth=r.getInt("TotalAmount");
             }
               System.out.println(sumOfSalesLastMonth);
       
        } catch (SQLException exc) {
            System.out.println(exc.getMessage());
        }
        }


    public Products getProducts() throws RemoteException {
        return (Products) products;
    }

    public Sale getSale() throws RemoteException {
        return (Sale) sale;
    }

    public Products getProducts(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Sale getSale(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}


